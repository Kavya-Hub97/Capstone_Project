package com.upgrad.bookmyconsultation.exception;

public class ResourceUnAvailableException extends RuntimeException{
}
